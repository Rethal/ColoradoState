Brenton Grundman
829460164
CS356 PA1

To make:
make

To run:
encrypt (B/S) {Input File} {Output File} {Key File} (E/D)