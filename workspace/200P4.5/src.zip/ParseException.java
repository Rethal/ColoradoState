
@SuppressWarnings("serial")
public class ParseException  extends Exception {
    // DON'T CHANGE THIS CODE
    public ParseException(){
    	super("");
    }
    public ParseException(String message){
    	super(message);
    }

}
