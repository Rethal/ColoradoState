
@SuppressWarnings("serial")
public class BSTException extends Exception {
	public BSTException(){
    	super("");
    }
    public BSTException(String message){
    	super(message);
    }
}
