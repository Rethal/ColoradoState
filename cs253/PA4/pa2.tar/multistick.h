#ifndef FIGURE_COMPARE
#define FIGURE_COMPARE
#include <iostream>
#include <fstream>
#include <sstream>
#include <PoseDisplay.h>
#include <Point3D.h>
#include <cmath>
#include <stick.h>

//using namespace std;
//
//class multistick {
//public:
//	multistick(){};
//	int comparePosesMulti(const stick& StickShort, const stick& StickLong);
//	bool openOutFileMulti(string outFile);
//	bool writeDistanceMulti();
//	int fileDistPrintMulti(const stick& firstIn, const stick& secondIn, string outFile);
//
//};


#endif