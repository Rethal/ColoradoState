Brenton Grundman 829460164
To make: make
To run: ./chat
	./chat -s <ip address> -p <port number>
	./chat -p <port number> -s <ip address>
help:	./chat -h


Currently, I do not quite have working code - getting these functions operable has befuddled
me.  I think I am close, but I'm not quite there.  To that end, I know my code won't reach
some of the test cases, but I think a tester can see that the code does in fact account for
these situations and should test appropriately!  Please take this into account during your
grading.

Another note is that I think a Piazza message board has been highly crucial to my learning
and understanding of classes in the past.  I think it would be a huge boon to anyone in
my situation who needs quick help in understanding what he's doing wrong (as it seems to be
very slight to me) to have.