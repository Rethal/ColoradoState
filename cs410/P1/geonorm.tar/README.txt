Code by Brent Grundman 829460164

To compile:
make

To run (example):
geonorm cube.ply